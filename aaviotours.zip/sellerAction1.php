<?php
include_once('db/model.php');
require_once('phpmailer/PHPMailerAutoload.php');
$db=new model();

$nameofestablish=$_REQUEST['nameofestablish'];
$panno=$_REQUEST['panno'];
$ownername=$_REQUEST['ownername'];
$tinno=$_REQUEST['tinno'];
$partnername1=$_REQUEST['partnername1'];
$partnermobno1=$_REQUEST['partnermobno1'];
$authorised=$_REQUEST['authorised'];
$auth_mobno=$_REQUEST['auth_mobno'];
$auth_email=$_REQUEST['auth_email'];
$address=$_REQUEST['address'];
$district=$_REQUEST['district'];
$pin=$_REQUEST['pin'];
$acc_holder=$_REQUEST['acc_holder'];
$acc_no=$_REQUEST['acc_no'];
$acc_bank=$_REQUEST['acc_bank'];
$acc_branch=$_REQUEST['acc_branch'];
$productdetails=$_REQUEST['productdetails'];
$acc_ifsc=$_REQUEST['acc_ifsc'];
$sellertype=$_REQUEST['sellertype'];

$dateofreg=date("Y-m-d");
$year=date("Y");

$details=$_REQUEST['others'];


$content='Name of Business : '.$nameofestablish.PHP_EOL.'
Business Type : '.$sellertype.PHP_EOL.'
Address : '.$address.PHP_EOL.'
District  : '.$district.PHP_EOL.'
Pin    : '.$pin.PHP_EOL.'
PAN No 		: '.$panno.PHP_EOL.'
Owner Name 	: '.$ownername.PHP_EOL.'
official email. : '.$tinno.PHP_EOL.'
Partners Name 	: '.$partnername1.PHP_EOL.'
Mob No. 	: '.$partnermobno1.PHP_EOL.'
Name of Authorised person/s : '.$authorised.PHP_EOL.'
Mob No.  : '.$auth_mobno.PHP_EOL.'
Email 	: '.$auth_email.PHP_EOL.'
Bank Details: Account Holder  : '.$acc_holder.PHP_EOL.'
Account No. 	: '.$acc_no.PHP_EOL.'
Bank 	: '.$acc_bank.PHP_EOL.'
Branch 	: '.$acc_branch.PHP_EOL.'
IFSC Code 	: '.$acc_ifsc.PHP_EOL.'
Other 	: '.$details.PHP_EOL.'
Date  : '.$dateofreg;


$randno=rand(100,9999);
$filename=$randno.'_'.$nameofestablish.'.txt';

$fp = fopen('sellers/'.$filename, 'w');
fwrite($fp, $content);
fclose($fp);
$seller_regno=$db->getlastregno();
$sell_year=substr($seller_regno, strpos($seller_regno, "-") + 1);
$new_seller_regno1=$sell_year+1;
$new_seller_regno=$year.'-'.$new_seller_regno1;


$to="tours@aavio.in";
$name="Varsha AavioTours";
$subject='Tours Seller Registration';
$message="Please find the Attachment";

$to1=$tinno;
$name1=$nameofestablish;
$subject1='Your registration with Aaviana Tourism LLP';
$message1='Dear Associate,<br>
<br>
Thank you for registering with us.<br>
Please note your Associate ID is : '.$new_seller_regno.'<br>
<br>
Please use this ID for all future communication.<br>
<br>
<br>
We expect your constant coordination and support in future. <br>
For Help please call 86065 01234 or 86064 01234. Emergency No. 8097795909 , Whatsapp No. 88798 60520<br>
<br>
You may email us to tours@aavio.in  or  care@aavio.in <br>
<br>
Thanking You<br>
Varsha Shivadasan<br>
Operations Head<br>
Aaviana Tourism LLP<br>


';

$mail=email($to,$name,$subject,$message,$filename);
//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
	$db->insertseller($nameofestablish,$tinno,$auth_mobno,$dateofreg,$filename,$new_seller_regno);
	$mail1 = email($to1,$name1,$subject1,$message1);
	$mail1->send();
    header('location:http://aaviotours.in/aavio_thanks');
}

function email($to,$name,$subject,$message,$filename=""){

//Create a new PHPMailer instance
$mail = new PHPMailer();
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 0;
//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';
//Set the hostname of the mail server
$mail->Host = "mail.aavio.in";
//Set the SMTP port number - likely to be 25, 465 or 587
$mail->Port = 25;
//Whether to use SMTP authentication
$mail->SMTPAuth = true;
//Username to use for SMTP authentication
$mail->Username = "sellers@aavio.in";
//Password to use for SMTP authentication
$mail->Password = "GroW@12#B5";
//Set who the message is to be sent from
$mail->setFrom('sellers@aavio.in', 'Aavio.in');
//Set an alternative reply-to address
$mail->addReplyTo('sellers@aavio.in', 'Aavio.in');
//Set who the message is to be sent to
$mail->addAddress($to, $name);
//Set the subject line
$mail->Subject = $subject;
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
  //$mail->msgHTML($message);
  
  $mail->Body    = $message;
  $mail->IsHTML(true);
  
//Replace the plain text body with one created manually
$mail->AltBody = 'This is a plain-text message body';
//Attach an image file
if($filename!=""){
  $mail->addAttachment('sellers/'.$filename);
}	
return $mail;
}



?>



