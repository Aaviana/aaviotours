<footer id="footer" class="style3">
            <div class="footer-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4">
                            <h2>Discover</h2>
                            <ul class="discover triangle hover row">
                                <li class="col-xs-6"><a href="kerala">Home</a></li>
                                <li class="col-xs-6"><a href="about">About</a></li>
                                <li class="col-xs-6"><a href="register">Seller Register</a></li>
                                <li class="col-xs-6"><a href="hotels">Hotels</a></li>
                                <li class="col-xs-6"><a href="contact">Contact</a></li>
                                <li class="col-xs-6"><a href="cars">Cars</a></li>
                                <li class="col-xs-6"><a href="safety">Safety</a></li>
                                <li class="col-xs-6"><a href="tour-packages">Tour Packages</a></li>
                                <li class="col-xs-6"><a href="login">Login</a></li>
                                <li class="col-xs-6"><a href="houseboats">Houseboats</a></li>
                               <!-- <li class="col-xs-6"><a href="#">Site Map</a></li>
                                <li class="col-xs-6"><a href="#">Policies</a></li>-->
                            </ul>
                        </div>
                        
                        <div class="col-sm-6 col-md-4">
                            <h2>Mailing List</h2>
                            <p>Sign up for our mailing list to get latest updates and offers.</p>
                            <br />
                            <div class="icon-check">
                                <input type="text" class="input-text full-width" placeholder="your email" />
                            </div>
                            <br />
                            <span>We respect your privacy</span>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <h2>About Aaviana Tourism</h2>
                            <p>Aaviana Tourism is dedicated to promote tourism in Kerala all around the world.</p>
                            <br />
                            <address class="contact-details">
                                <span class="contact-phone"><i class="soap-icon-phone"></i> 91-860-650-1234</span>
                                <br />
                                <a href="#" class="contact-email">tours@aavio.in</a>
                            </address>
                            <ul class="social-icons clearfix">
                                <li class="twitter"><a title="twitter" href="#" data-toggle="tooltip"><i class="soap-icon-twitter"></i></a></li>
                                <li class="googleplus"><a title="googleplus" href="#" data-toggle="tooltip"><i class="soap-icon-googleplus"></i></a></li>
                                <li class="facebook"><a title="facebook" href="#" data-toggle="tooltip"><i class="soap-icon-facebook"></i></a></li>
                                <li class="linkedin"><a title="linkedin" href="#" data-toggle="tooltip"><i class="soap-icon-linkedin"></i></a></li>
                                <li class="vimeo"><a title="vimeo" href="#" data-toggle="tooltip"><i class="soap-icon-vimeo"></i></a></li>
                                <li class="dribble"><a title="dribble" href="#" data-toggle="tooltip"><i class="soap-icon-dribble"></i></a></li>
                                <li class="flickr"><a title="flickr" href="#" data-toggle="tooltip"><i class="soap-icon-flickr"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom gray-area">
                <div class="container">
                    <div class="logo pull-left">
                        <a href="kerala" title="Aavio Tourism">
                            <img src="images/logo.png" alt="Aavio Tourism" />
                        </a>
                    </div>
                    <div class="pull-right">
                        <a id="back-to-top" href="#" class="animated" data-animation-type="bounce"><i class="soap-icon-longarrow-up circle"></i></a>
                    </div>
                    <div class="copyright pull-right">
                        <p>&copy; 2017 Aaviana Tourism</p>
                    </div>
                </div>
            </div>
        </footer>