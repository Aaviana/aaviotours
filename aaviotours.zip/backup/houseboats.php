<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Current Page Styles -->
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/settings.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/jquery.bxslider/jquery.bxslider.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/flexslider/flexslider.css" media="screen" />
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    
    <div id="page-wrapper">
       <?php include_once('header.php');?>
        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">HouseBoats</h2>
                </div>
               
            </div>
        </div>
        <section id="content">
            <div class="container">
                <div id="main">
                    <div class="row">
                        <div class="col-sm-4 col-md-3">
                            <h4 class="search-results-title"><i class="soap-icon-search"></i><b>1,984</b> results found.</h4>
                            <div class="toggle-container filters-container">
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#price-filter" class="collapsed">Price</a>
                                    </h4>
                                    <div id="price-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <div id="price-range"></div>
                                            <br />
                                            <span class="min-price-label pull-left"></span>
                                            <span class="max-price-label pull-right"></span>
                                            <div class="clearer"></div>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#rating-filter" class="collapsed">User Rating</a>
                                    </h4>
                                    <div id="rating-filter" class="panel-collapse collapse filters-container">
                                        <div class="panel-content">
                                            <div id="rating" class="five-stars-container editable-rating"></div>
                                            <p class="reviews"><small>2458 REVIEWS</small></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#cruise-length-filter" class="collapsed">Cruises Length</a>
                                    </h4>
                                    <div id="cruise-length-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <div id="cruise-length-range" class="slider-color-yellow"></div>
                                            <br />
                                            <span class="min-cruise-length pull-left">0</span>
                                            <span class="max-cruise-length pull-right"></span>
                                            <div class="clearer"></div>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#cruise-line-filter" class="collapsed">Cruise Line</a>
                                    </h4>
                                    <div id="cruise-line-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">Any<small>(722)</small></a></li>
                                                <li><a href="#">Azamara<small>(982)</small></a></li>
                                                <li><a href="#">Princess cruises<small>(127)</small></a></li>
                                                <li class="active"><a href="#">cunard line<small>(222)</small></a></li>
                                                <li><a href="#">MSC Cruises<small>(158)</small></a></li>
                                                <li><a href="#">aida cruises<small>(439)</small></a></li>
                                                <li><a href="#">celebrity cruises<small>(52)</small></a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#cruise-preference-filter" class="collapsed">Cruise Preference</a>
                                    </h4>
                                    <div id="cruise-preference-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">buffet restaurant</a></li>
                                                <li><a href="#">Entertainment</a></li>
                                                <li class="active"><a href="#">swimming pools</a></li>
                                                <li class="active"><a href="#">Clubs</a></li>
                                                <li><a href="#">fitness center</a></li>
                                                <li><a href="#">Live Shows</a></li>
                                                <li><a href="#">Duty Free shops</a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#cruise-cabin-type-filter" class="collapsed">Cabin Type</a>
                                    </h4>
                                    <div id="cruise-cabin-type-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">Inside<small>(INR 3620)</small></a></li>
                                                <li><a href="#">Oceanview<small>(INR 3982)</small></a></li>
                                                <li class="active"><a href="#">Balcony<small>(INR 3127)</small></a></li>
                                                <li class="active"><a href="#">Suites<small>(INR 3222)</small></a></li>
                                                <li><a href="#">Junior Suite<small>(INR 3158)</small></a></li>
                                                <li><a href="#">Suite w/ Balcony<small>(INR 3439)</small></a></li>
                                                <li><a href="#">Outside<small>(INR 352)</small></a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#modify-search-panel" class="collapsed">Modify Search</a>
                                    </h4>
                                    <div id="modify-search-panel" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <form method="post">
                                                <div class="form-group">
                                                    <label>destination</label>
                                                    <input type="text" class="input-text full-width" placeholder="" value="Paris" />
                                                </div>
                                                <div class="form-group">
                                                    <label>Departure date</label>
                                                    <div class="datepicker-wrap">
                                                        <input type="text" class="input-text full-width" placeholder="mm/dd/yy" />
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Cruise Length</label>
                                                    <div class="selector full-width">
                                                        <select>
                                                            <option value="">select cruise length</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Cruise line</label>
                                                    <div class="selector full-width">
                                                        <select>
                                                            <option value="">select cruise line</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <button type="submit" class="btn-medium icon-check uppercase full-width">search again</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8 col-md-9">
                            <div class="sort-by-section box clearfix">
                                <h4 class="sort-by-title block-sm">Sort results by:</h4>
                                <ul class="sort-bar clearfix block-sm">
                                    <li class="sort-by-name"><a class="sort-by-container" href="#"><span>name</span></a></li>
                                    <li class="sort-by-price"><a class="sort-by-container" href="#"><span>price</span></a></li>
                                    <li class="clearer visible-sms"></li>
                                    <li class="sort-by-date active"><a class="sort-by-container" href="#"><span>date</span></a></li>
                                    <li class="sort-by-cruise-line"><a class="sort-by-container" href="#"><span>cruise line</span></a></li>
                                </ul>
                                
                                <ul class="swap-tiles clearfix block-sm">
                                    <li class="swap-list">
                                        <a href="cruise-list-view.html"><i class="soap-icon-list"></i></a>
                                    </li>
                                    <li class="swap-grid">
                                        <a href="cruise-grid-view.html"><i class="soap-icon-grid"></i></a>
                                    </li>
                                    <li class="swap-block active">
                                        <a href="cruise-block-view.html"><i class="soap-icon-block"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="cruise-list row image-box listing-style2 add-clearfix">
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb1.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">ONE BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 6170</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb2.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">TWO BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 7169</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb3.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">THREE BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 8299</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb4.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">FOUR BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 9149</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb5.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">FIVE BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 10209</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-sms-6 col-sm-6 col-md-4">
                                    <article class="box">
                                        <figure>
                                            <a href="ajax/cruise-slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/hb6.jpg" alt="" width="270" height="160" /></a>
                                        </figure>
                                        <div class="details">
                                            <a title="View Detailed" href="houseboat" class="pull-right button btn-mini uppercase">select</a>
                                            <h4 class="box-title">SIX BEDROOM</h4>
                                            <label class="price-wrapper">
                                                <span class="price-per-unit">INR 15132</span>over nights
                                            </label>
                                        </div>
                                    </article>
                                </div>
                               
                               
                            </div>
                            <a href="#" class="uppercase full-width button btn-large">load more listing</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
         <?php include_once('footer.php');?>
    </div>

    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- load revolution slider scripts -->
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.revolution.min.js"></script>
    
    <!-- load BXSlider scripts -->
    <script type="text/javascript" src="components/jquery.bxslider/jquery.bxslider.min.js"></script>
    
    <!-- load FlexSlider scripts -->
    <script type="text/javascript" src="components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- Google Map Api -->
    <script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
    <script type="text/javascript">
        tjq(document).ready(function() {
            tjq("#price-range").slider({
                range: true,
                min: 0,
                max: 1000,
                values: [ 100, 800 ],
                slide: function( event, ui ) {
                    tjq(".min-price-label").html( "$" + ui.values[ 0 ]);
                    tjq(".max-price-label").html( "$" + ui.values[ 1 ]);
                }
            });
            tjq(".min-price-label").html( "$" + tjq("#price-range").slider( "values", 0 ));
            tjq(".max-price-label").html( "$" + tjq("#price-range").slider( "values", 1 ));

            tjq("#cruise-length-range").slider({
                range: "min",
                min: 0,
                max: 12,
                value: 10,
                slide: function( event, ui ) {
                    tjq(".max-cruise-length").html( ui.value + " NIGHTS" );
                }
            });
            tjq(".max-cruise-length").html( tjq("#cruise-length-range").slider( "value" ) + " NIGHTS" );

            tjq("#rating").slider({
                range: "min",
                value: 40,
                min: 0,
                max: 50,
                slide: function( event, ui ) {
                    
                }
            });
        });
    </script>
</body>
</html>

