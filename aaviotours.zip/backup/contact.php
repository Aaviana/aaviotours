<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
        <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">Contact Us</h2>
                </div>
                <ul class="breadcrumbs pull-right">
                    <li><a href="kerala">HOME</a></li>
                    <li class="active">Contact Us</li>
                </ul>
            </div>
        </div>
        <div class="travelo-google-map full-box">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d981.9238398169599!2d76.33920912922785!3d10.124003119771237!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080f15efbfe553%3A0xdec02921d8f7d004!2sAaviana+Trading+LLP!5e0!3m2!1sen!2sin!4v1493358370770" width="100%" height="400" frameborder="0" style="border:0" ></iframe>
		</div>
        <section id="content" class="white-bg">
            <div class="container">
                <div id="main">
                    <div class="col-md-9 no-float no-padding center-block">
                        <div class="intro text-center block">
                            <h2>Send us a Message</h2>
                            <p>Etiam gravida ac mi ut posuere. Nunc laoreet nulla a porttitor volutpat. Praesent in rutrum justo, in fermentum nulla. Ut vel nulla tincidunt, lobortis tortor eu, venenatis ligula. Vivamus laoreet leo nulla, nec venenatis erat laoreet et. Integer tincidunt nulla at leo dignissim, ut iaculis libero mattis.</p>
                        </div>
                        <form class="contact-form1" action="http://aavio.in/contact-us-handler.php" method="post">
                            <div class="alert small-box" style="display: none;"></div>
                            <div class="row form-group">
                                <div class="col-xs-6">
                                    <label>Your Name</label>
                                    <input type="text" name="name" class="input-text full-width">
                                </div>
                                <div class="col-xs-6">
                                    <label>Your Email</label>
                                    <input type="text" name="email" class="input-text full-width">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-xs-6">
                                    <label>Subject</label>
                                    <input type="text" name="subject" class="input-text full-width">
                                </div>
                                <div class="col-xs-6">
                                    <label>Website</label>
                                    <input type="text" name="website" class="input-text full-width">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Your Message</label>
                                <textarea name="message" rows="6" class="input-text full-width" placeholder="write message here"></textarea>
                            </div>
                            <button type="submit" class="btn-large full-width">SEND MESSAGE</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="global-map-area section contact-details parallax" data-stellar-background-ratio="0.5">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="icon-box style10 phone">
                                <i class="soap-icon-phone"></i>
                                <small>We are on 24/7</small>
                                <h4 class="box-title">91-8606-501-234</h4>
                                <p class="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="icon-box style10 email">
                                <i class="soap-icon-message"></i>
                                <small>Send us email on</small>
                                <h4 class="box-title">tours@aavio.in</h4>
                                <p class="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="icon-box style10 address">
                                <i class="soap-icon-address"></i>
                                <small>Meet us now</small>
                                <h4 class="box-title">Aaviana Tourism LLP</h4>
                                <p class="description">3rd Floor, Surya Square, Mangalapuzha Bridge, Seminary Road Junction, Dist. Ernakulam, Aluva-683102 </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php include_once('footer.php');?>
    </div>


    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>

    <!-- Google Map Api -->
    <script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/contact.js"></script>

    <script type="text/javascript">
        tjq(".travelo-google-map1").gmap3({
            map: {
                options: {
                    center: [48.85661, 2.35222],
                    zoom: 12
                }
            },
            marker:{
                values: [
                    {latLng:[10.1240031, 2.35222], data:"Aaviana"}

                ],
                options: {
                    draggable: false
                },
            }
        });
		
		https://www.google.co.in/maps/place/Aaviana+Trading+LLP/@10.1240031,76.3392091,19z/data=!4m5!3m4!1s0x3b080f15efbfe553:0xdec02921d8f7d004!8m2!3d10.1240018!4d76.3397563
    </script>
</body>
</html>

