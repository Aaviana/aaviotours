<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
       <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">Tour Packages </h2>
                </div>
               
            </div>
        </div>

        <section id="content">
            <div class="container">
                <div id="main">
                    <div class="row add-clearfix image-box style1 tour-locations">
                        <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/munnarpackage.jpg" height="200" width="370" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">MUNNAR TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/tp8.jpg" height="200" width="370" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">WAYANAD TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/tp7.jpg" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">ALLEPPY TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/tp6.jpg" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">KUMARAKOM TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                       <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/tp5.jpg" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">HONEYMOON TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box">
                                <figure>
                                    <a href="#" class="hover-effect">
                                        <img src="images/uploads/tp3.jpg" alt="">
                                    </a>
                                </figure>
                                <div class="details">
                                    <span class="price">INR 9620</span>
                                    <h4 class="box-title">FAMILY TOUR </h4>
                                    <hr>
                                    <ul class="features check">
                                        <li>A/C Car transportation</li>
                                        <li>Enjoy World Famous Restaurant</li>
                                        <li>Night Street Life in Downtown </li>
                                    </ul>
                                    <hr>
                                    <div class="text-center">
                                        <div class="time">
                                            <i class="soap-icon-clock yellow-color"></i>
                                            <span>01 Nov 2016 - 08 Nov 2017</span>
                                        </div>
                                    </div>
                                    <a href="tour-detail" class="button btn-small full-width">BOOK NOW</a>
                                </div>
                            </article>
                        </div>
                        
                       
                    </div>
                    <a href="#" class="button btn-large full-width uppercase">Load More Packages</a>
                </div>
            </div>
        </section>
        
         <?php include_once('footer.php');?>
    </div>
    

    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
</body>
</html>

