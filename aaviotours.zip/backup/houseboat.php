<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
       <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">Aavio Houseboats</h2>
                </div>
               
            </div>
        </div>

        <section id="content">
            <div class="container tour-detail-page">
                <div class="row">
                    <div id="main" class="col-md-9">
                        <div class="featured-gallery image-box">
                            <span class="discount"><span class="discount-text">10% Discount</span></span>
                            <div class="flexslider photo-gallery style1" id="post-slideshow1" data-sync="#post-carousel1" data-func-on-start="showTourDetailedDiscount">
                                <ul class="slides">
                                    <li><a href="pages-blog-read.html"><img src="images/uploads/hbi2.jpg" alt=""></a></li>
                                    <li><a href="pages-blog-read.html"><img src="images/uploads/hbi1.jpg" alt=""></a></li>
                                    
                                </ul>
                            </div>
                            <div class="flexslider image-carousel style1" id="post-carousel1"  data-animation="slide" data-item-width="70" data-item-margin="10" data-sync="#post-slideshow1">
                                <ul class="slides">
                                    <li><img src="images/uploads/hbi2.jpg" alt="" /></li>
                                    <li><img src="images/uploads/hbi1.jpg" alt="" /></li>
                                    
                                </ul>
                            </div>
                        </div>

                        <div id="tour-details" class="travelo-box">
                            <div class="intro2 small-box border-box table-wrapper hidden-table-sms">
                                <div class="image-container table-cell"><img src="images/uploads/hbi2.jpg" alt=""></div>
                                <div class="table-cell">
                                    <dl class="term-description">
                                        <dt>Location:</dt><dd>Alleppy</dd>
                                        <dt>No of Rooms</dt><dd>3</dd>
                                        <dt>Duration Type:</dt><dd>Over Night</dd>
                                        <dt>Room Type:</dt><dd>Deluxe</dd>
										<dt>Check In</dt><dd>11 a.m</dd>
										<dt>Check Out</dt><dd>9 a.m</dd>
                                    </dl>
                                </div>
                                <div class="price-section table-cell">
                                    <div class="price"><small>overnight</small><div class="price-per-unit">INR 5500</div></div>
                                    <a href="tour-booking.html" class="button green btn-small uppercase">Book Now</a>
                                </div>
                            </div>
							
							 <div class="intro2 small-box border-box table-wrapper hidden-table-sms">
                                <div class="image-container table-cell"><img src="images/uploads/hbi1.jpg" alt=""></div>
                                <div class="table-cell">
                                    <dl class="term-description">
                                         <dt>Location:</dt><dd>Alleppy</dd>
                                        <dt>No of Rooms</dt><dd>45</dd>
                                        <dt>Duration Type:</dt><dd>Day Curise</dd>
                                        <dt>Room Type:</dt><dd>Deluxe</dd>
										<dt>Check In</dt><dd>10 a.m</dd>
										<dt>Check Out</dt><dd>6 p.m</dd>
                                    </dl>
                                </div>
                                <div class="price-section table-cell">
                                    <div class="price"><small>per hour</small><div class="price-per-unit">INR 1500</div></div>
                                    <a href="tour-booking.html" class="button green btn-small uppercase">Book Now</a>
                                </div>
                            </div>

                            

                            <h3>Inclusions</h3>
                            <ul class="arrow box">
                                <li>Lunch + Tea + Dinner and Breakfast - Menu Veg or Non-Veg</li>
                               
                            </ul>
							
							 <h3>Extras</h3>
                            <ul class="arrow box">
                                <li>Children below 5-12 yrs without Extra Mattress - INR 500 </li>
                                <li>Children above 5-12 yrs with Extra Mattress - INR 1000 </li>
                                <li>Extra Person with Extra mattress - INR 1500 </li>
                            </ul>
						</div>
                    </div>
                    <div class="sidebar col-md-3">
                        <div class="travelo-box">
                            <h4 class="box-title">Last Minute Deals</h4>
                            <div class="image-box style14">
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Plaza Tour Eiffel</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">$170</span>avg/night</label>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Ocean Park Tour</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">$620</span>avg/night</label>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Dream World Trip</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">$322</span>avg/night</label>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="travelo-box book-with-us-box">
                            <h4>Why Book with us?</h4>
                            <ul>
                                <li>
                                    <i class="soap-icon-hotel-1 circle"></i>
                                    <h5 class="title"><a href="#">135,00+ Hotels</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                                <li>
                                    <i class="soap-icon-savings circle"></i>
                                    <h5 class="title"><a href="#">Low Rates &amp; Savings</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                                <li>
                                    <i class="soap-icon-support circle"></i>
                                    <h5 class="title"><a href="#">Excellent Support</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                            </ul>
                        </div>
                        <div class="travelo-box contact-box">
                            <h4 class="box-title">Need Travelo Help?</h4>
                            <p>We would be more than happy to help you. Our team advisor are 24/7 at your service to help you.</p>
                            <address class="contact-details">
                                <span class="contact-phone"><i class="soap-icon-phone"></i> 1-800-123-HELLO</span>
                                <br />
                                <a href="#" class="contact-email">help@travelo.com</a>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
         <?php include_once('footer.php');?>
    </div>
    

    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>

    <!-- Flex Slider -->
    <script type="text/javascript" src="components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- Google Map Api -->
    <script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>

    <script type="text/javascript">
        tjq(".tour-google-map").gmap3({
            map: {
                options: {
                    center: [48.85661, 2.35222],
                    zoom: 12
                }
            },
            marker:{
                values: [
                    {latLng:[48.85661, 2.35222], data:"Paris"}

                ],
                options: {
                    draggable: false
                },
            }
        });

        function showTourDetailedDiscount() {
            tjq(".featured-gallery .discount").css("visibility", "visible");
        }
    </script>
    
</body>
</html>

