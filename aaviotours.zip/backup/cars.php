<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Current Page Styles -->
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/settings.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/jquery.bxslider/jquery.bxslider.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/flexslider/flexslider.css" media="screen" />
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    
    <div id="page-wrapper">
        <?php include_once('header.php');?>
        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">Cars</h2>
                </div>
               
            </div>
        </div>
        <section id="content" class="gray-area">
            <div class="container">
                    <div id="main">
                    <div class="row">
                        <div class="col-sm-4 col-md-3">
                            <h4 class="search-results-title"><i class="soap-icon-search"></i><b>627</b> results found.</h4>
                            <div class="toggle-container filters-container">
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#price-filter" class="collapsed">Price</a>
                                    </h4>
                                    <div id="price-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <div id="price-range"></div>
                                            <br />
                                            <span class="min-price-label pull-left"></span>
                                            <span class="max-price-label pull-right"></span>
                                            <div class="clearer"></div>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#cartype-filter" class="collapsed">Car Type</a>
                                    </h4>
                                    <div id="cartype-filter" class="panel-collapse collapse filters-container">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">Full Size<small>(10)</small></a></li>
                                                <li><a href="#">Compact<small>(82)</small></a></li>
                                                <li class="active"><a href="#">Economy<small>(127)</small></a></li>
                                                <li><a href="#">Luxury / Premium<small>(22)</small></a></li>
                                                <li><a href="#">Mini Car<small>(38)</small></a></li>
                                                <li><a href="#">Van / Minivan<small>(39)</small></a></li>
                                                <li><a href="#">Exotic / Special<small>(72)</small></a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#car-rental-agent-filter" class="collapsed">Car Rental Agent</a>
                                    </h4>
                                    <div id="car-rental-agent-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">Fox Rent A Car<small>(08)</small></a></li>
                                                <li><a href="#">Payless<small>(32)</small></a></li>
                                                <li class="active"><a href="#">Ez rent a car<small>(227)</small></a></li>
                                                <li><a href="#">Thrifty<small>(22)</small></a></li>
                                                <li><a href="#">Enterprise<small>(18)</small></a></li>
                                                <li><a href="#">Alamo<small>(29)</small></a></li>
                                                <li><a href="#">Dollar<small>(12)</small></a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#car-preferences-filter" class="collapsed">Car Preferences</a>
                                    </h4>
                                    <div id="car-preferences-filter" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <ul class="check-square filters-option">
                                                <li><a href="#">Passenger Quantity</a></li>
                                                <li class="active"><a href="#">Satellite Navigation</a></li>
                                                <li class="active"><a href="#">Air Conditioning</a></li>
                                                <li><a href="#">Doors</a></li>
                                                <li><a href="#">Diesel Vehicle</a></li>
                                            </ul>
                                            <a class="button btn-mini">MORE</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="panel style1 arrow-right">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" href="#modify-search-panel" class="collapsed">Modify Search</a>
                                    </h4>
                                    <div id="modify-search-panel" class="panel-collapse collapse">
                                        <div class="panel-content">
                                            <form method="post">
                                                <div class="form-group">
                                                    <label>pickup from</label>
                                                    <input type="text" class="input-text full-width" placeholder="city, district, or specific airpot" value="" />
                                                </div>
                                                <div class="form-group">
                                                    <label>pick-up date</label>
                                                    <div class="datepicker-wrap">
                                                        <input type="text" name="date_from" class="input-text full-width" placeholder="mm/dd/yy" />
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>drop-off date</label>
                                                    <div class="datepicker-wrap">
                                                        <input type="text" name="date_to" class="input-text full-width" placeholder="mm/dd/yy" />
                                                    </div>
                                                </div>
                                                <br />
                                                <button class="btn-medium icon-check uppercase full-width">search again</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8 col-md-9">
                            <div class="sort-by-section clearfix">
                                <h4 class="sort-by-title block-sm">Sort results by:</h4>
                                <ul class="sort-bar clearfix block-sm">
                                    <li class="sort-by-name"><a class="sort-by-container" href="#"><span>name</span></a></li>
                                    <li class="sort-by-price"><a class="sort-by-container" href="#"><span>price</span></a></li>
                                    <li class="clearer visible-sms"></li>
                                    <li class="sort-by-rating active"><a class="sort-by-container" href="#"><span>rating</span></a></li>
                                    <li class="sort-by-popularity"><a class="sort-by-container" href="#"><span>popularity</span></a></li>
                                </ul>
                                
                                <ul class="swap-tiles clearfix block-sm">
                                    <li class="swap-list active">
                                        <a href="car-list-view.html"><i class="soap-icon-list"></i></a>
                                    </li>
                                    <li class="swap-grid">
                                        <a href="car-grid-view.html"><i class="soap-icon-grid"></i></a>
                                    </li>
                                    <li class="swap-block">
                                        <a href="car-block-view.html"><i class="soap-icon-block"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="car-list listing-style3 car">
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn6.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Toyota Etios<small>Economy Car</small></h4>
                                                <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl class="">
                                                <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>13</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 1500</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn4.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Maruti Swift<small>Economy Car</small></h4>
                                                 <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl class="">
                                                <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>15</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 1500</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn3.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Traveller 14 seat<small>Luxury Elite</small></h4>
                                                 <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl>
                                                <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>15</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 2500</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn2.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Traveller 17 seat<small>Deluxe Elite</small></h4>
                                                <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl>
                                                <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>15</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 3000</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn1.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Mini Bus<small>Intermediate</small></h4>
                                                 <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl>
                                               <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>30</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 6500</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure class="col-xs-3">
                                        <span><img alt="" src="images/uploads/tn5.jpg"></span>
                                    </figure>
                                    <div class="details col-xs-9 clearfix">
                                        <div class="col-sm-8">
                                            <div class="clearfix">
                                                <h4 class="box-title">Volvo 49 seat<small>Luxury Bus</small></h4>
                                                <!--<div class="logo">
                                                    <img src="http://placehold.it/110x25" alt="" />
                                                </div>-->
                                            </div>
                                            <div class="amenities">
                                                <ul>
                                                    <li><i class="soap-icon-user circle"></i>4</li>
                                                    <li><i class="soap-icon-suitcase circle"></i>3</li>
                                                    <li><i class="soap-icon-aircon circle"></i>AC</li>
                                                    <li><i class="soap-icon-fueltank circle"></i>12</li>
                                                    <li><i class="soap-icon-fmstereo circle"></i>YES</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-6 col-sm-2 character">
                                            <dl>
                                                <dt class="skin-color">Location</dt><dd>Cochin</dd>
                                                <dt class="skin-color">Max. KM</dt><dd>100</dd>
                                                <dt class="skin-color">Extra KM</dt><dd>50</dd>
                                            </dl>
                                        </div>
                                        <div class="action col-xs-6 col-sm-2">
                                            <span class="price"><small>per day</small>INR 9000</span>
                                            <a href="car-booking" class="button btn-small full-width">select</a>
                                        </div>
                                    </div>
                                </article>
                               
                            </div>
                            <a href="#" class="button uppercase full-width btn-large">load more listings</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php include_once('footer.php');?>
    </div>

    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- load revolution slider scripts -->
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.revolution.min.js"></script>
    
    <!-- load BXSlider scripts -->
    <script type="text/javascript" src="components/jquery.bxslider/jquery.bxslider.min.js"></script>
    
    <!-- load FlexSlider scripts -->
    <script type="text/javascript" src="components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- Google Map Api -->
    <script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
    <script type="text/javascript">
        tjq(document).ready(function() {
            tjq("#price-range").slider({
                range: true,
                min: 0,
                max: 1000,
                values: [ 100, 800 ],
                slide: function( event, ui ) {
                    tjq(".min-price-label").html( "$" + ui.values[ 0 ]);
                    tjq(".max-price-label").html( "$" + ui.values[ 1 ]);
                }
            });
            tjq(".min-price-label").html( "$" + tjq("#price-range").slider( "values", 0 ));
            tjq(".max-price-label").html( "$" + tjq("#price-range").slider( "values", 1 ));
        });
    </script>
</body>
</html>

