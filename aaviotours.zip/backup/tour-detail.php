<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
       <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">MUNNAR TOUR (03 NIGHTS 04 DAYS) </h2>
                </div>
                
            </div>
        </div>

        <section id="content">
            <div class="container tour-detail-page">
                <div class="row">
                    <div id="main" class="col-md-9">
                        <div class="featured-image">
                            <img src="images/uploads/munnar.jpg" alt="Munnar" />
                        </div>

						<div id="tour-details" class="travelo-box">
                            <div class="intro2 small-box border-box table-wrapper hidden-table-sms">
                                <div class="image-container table-cell"><img src="images/uploads/munnarpackage.jpg" alt=""></div>
                                <div class="table-cell">
                                    <dl class="term-description">
                                        <dt>Locationw:</dt><dd>:COCHIN - MUNNAR - THEKKADY - COCHIN</dd>
                                        <dt>Days:</dt><dd>4</dd>
                                        <dt>Nights:</dt><dd>3</dd>
                                        <dt>Price:</dt><dd>INR 9534</dd>
                                    </dl>
                                </div>
                                <div class="price-section table-cell">
                                    <div class="price"><small>4 days tour</small><div class="price-per-unit">INR 9534</div></div>
                                    <a href="tour-booking.html" class="button green btn-small uppercase">Book Tour</a>
                                </div>
                            </div>

                            

                <div class="tab-wrapper">
					<div class="tab-container style1" style="margin-top:0px;">
                    <ul class="tabs no-padding">
                        <li><a data-toggle="tab" href="#family1"><i class="soap-icon-family"></i>Itinerary</a></li>
                        <li class="active"><a data-toggle="tab" href="#honeymoon1"><i class="soap-icon-couples"></i>Hotels</a></li>
                        <li><a data-toggle="tab" href="#weekends1"><i class="soap-icon-availability"></i>Inclusions</a></li>
                        <li><a data-toggle="tab" href="#friends1"><i class="soap-icon-friends"></i>Exclusions</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="family1" class="tab-pane fade">
                            <div class="md-section">
                                <h2 class="skin-color">Itinerary</h2>
								<h2>General Information About Package</h2>
                            <p>Our Munnar TOUR Package is unchallenging for its excellence and perfection, as we consider customer satisfaction as our supreme priority. The entire munnar tour package build up in a manner that our customer can enjoy its maximum benefits from our enhanced and trained faculty and with our prestigious accomodation facilities. The resorts and accomodation cottages we consolidate into our Munnar tour package are arranged in the midst of Munnar Tea Gardens and Munnar Hills for providing a blissful natural experience. You can choose from the list of accomodation options so as to meet up with your slant and satisfaction. The reservations of the room can be made by necessities of your visit.</p>

                            <h2>Day 01</h2>
                            <p>Arrives cochin, Visit athirapally and vazhachal waterfalls. Overnight stay at hotel.</p>

                            <h2>Day 02</h2>
                            <p> Transfer to munnar Visit Cheeyapara and valara Water falls. Photo points with tea plantations. Overnight stay at hotel.</p>

                            <h2>Day 03</h2>
                            <p>Visit Mattupetty, Eco-Point, Tea Museum, Pothamedu etc Overnight stay at hotel.</p>
							 
							 <h2>Day 04</h2>
                            <p>Transfer to cochin for departure.</p>
                        
                            </div>
                        </div>
                        <div id="honeymoon1" class="tab-pane fade in active image-style style2">
                            <div class="row">
                                <div class="col-md-6 md-section">
                                    <h2 class="skin-color">Hotels</h2>
                                    <table class="table table-striped">
<thead><tr><th>Place</th><th>Hotel Name</th><th>Room Name</th><th>Nights</th></tr></thead>
<tbody>
	<tr><td>Cochin</td><td>Mariotte Hotel</td><td>Deluxe Room</td><td>1</td></tr>
  	<tr><td>Munnar</td><td>Spice Tree Resort</td><td>Classic(Jacuzzi)</td><td>2</td></tr>
</tbody>
</table>
                                </div>
                                
                            </div>
                        </div>
					  <div id="weekends1" class="tab-pane fade">
                            <div class="md-section">
                                <h2 class="skin-color">Inclusions</h2>
								
                            <ul class="arrow-square box">
                                <li>Accommodation in mentioned Hotels in double Room</li>
                                <li>Breakfast at all hotels</li>
                                <li>Arrival assistance</li>
                                <li>Service of an English speaking driver</li>
                            </ul>
                       
                            </div>
                        </div>
                        <div id="friends1" class="tab-pane fade">
                            <div class="md-section">
                                <h2 class="skin-color">Exclusions</h2>
								
                            <ul class="arrow-square box">
                                <li>Parking, Toll</li>
                                <li>All Taxes</li>
                            </ul>
                      
                            </div>
                        </div>
                    </div>
                </div>
            </div></div>
                    </div>
                    <div class="sidebar col-md-3">
                        <div class="travelo-box">
                            <h4 class="box-title">Last Minute Deals</h4>
                            <div class="image-box style14">
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Plaza Tour Eiffel</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">INR 9170</span>avg/night</label>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Ocean Park Tour</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">INR 9620</span>avg/night</label>
                                    </div>
                                </article>
                                <article class="box">
                                    <figure><a href="#" title=""><img width="63" height="59" src="http://placehold.it/63x60" alt=""></a></figure>
                                    <div class="details">
                                        <h5 class="box-title"><a href="#">Dream World Trip</a></h5>
                                        <label class="price-wrapper"><span class="price-per-unit">INR 9322</span>avg/night</label>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="travelo-box book-with-us-box">
                            <h4>Why Book with us?</h4>
                            <ul>
                                <li>
                                    <i class="soap-icon-hotel-1 circle"></i>
                                    <h5 class="title"><a href="#">135,00+ Hotels</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                                <li>
                                    <i class="soap-icon-savings circle"></i>
                                    <h5 class="title"><a href="#">Low Rates &amp; Savings</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                                <li>
                                    <i class="soap-icon-support circle"></i>
                                    <h5 class="title"><a href="#">Excellent Support</a></h5>
                                    <p>Nunc cursus libero pur congue arut nimspnty.</p>
                                </li>
                            </ul>
                        </div>
                        <div class="travelo-box contact-box">
                            <h4 class="box-title">Need Travelo Help?</h4>
                            <p>We would be more than happy to help you. Our team advisor are 24/7 at your service to help you.</p>
                            <address class="contact-details">
                                <span class="contact-phone"><i class="soap-icon-phone"></i> 1-800-123-HELLO</span>
                                <br />
                                <a href="#" class="contact-email">help@travelo.com</a>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
         <?php include_once('footer.php');?>
    </div>
    

    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- Google Map Api -->
    <script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>

    <script type="text/javascript">
        tjq(".tour-google-map").gmap3({
            map: {
                options: {
                    center: [48.85661, 2.35222],
                    zoom: 12
                }
            },
            marker:{
                values: [
                    {latLng:[48.85661, 2.35222], data:"Paris"}

                ],
                options: {
                    draggable: false
                },
            }
        });
    </script>
    
</body>
</html>

