<?php

 // #remove the directory path we don't want
  $request  = str_replace("/myworks/aaviotours/", "", $_SERVER['REQUEST_URI']);
  define("base_url","http://localhost/myworks/aaviotours/");
  //#split the path by '/'
  $params     = split("/", $request);
  //#keeps users from requesting any file they want
  $safe_pages = array("kerala", "hotels", "flights", "cars", "houseboats", "tour-packages", "contact","404","login","tour-detail","houseboat","car-booking","aavio_thanks_c","aavio_thanks","register","about","safety");
  if($params[0]==""){$params[0]="kerala";}
  if(in_array($params[0], $safe_pages)) {
    include($params[0].".php");
  } else {
    include("404.php");
  }
?>





