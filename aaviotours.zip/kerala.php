<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico?v=2" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Current Page Styles -->
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/settings.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/jquery.bxslider/jquery.bxslider.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/flexslider/flexslider.css" media="screen" />
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    
    <div id="page-wrapper">
        <?php include_once('header.php');?>
        <div id="slideshow">
            <div class="fullwidthbanner-container">
                <div class="revolution-slider rev_slider" style="height: 0; overflow: hidden;">
                    <ul>    <!-- SLIDE  -->
                        <!-- Slide1 -->
                        <li data-transition="zoomin" data-slotamount="7" data-masterspeed="1500">
                            <!-- MAIN IMAGE -->
                            <img src="images/uploads/s1.jpg" alt="">
                        </li>
                        
                        <!-- Slide2 -->
                        <li data-transition="zoomout" data-slotamount="7" data-masterspeed="1500">
                            <!-- MAIN IMAGE -->
                            <img src="images/uploads/s2.jpg" alt="">
                        </li>
                        
                        <!-- Slide3 -->
                        <li data-transition="slidedown" data-slotamount="7" data-masterspeed="1500">
                            <!-- MAIN IMAGE -->
                            <img src="images/uploads/s4.jpg" alt="">
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <section id="content">
           <?php include_once('bannersearch.php');?>

            <div class="section container">
                <div class="container">
                    <div class="text-center description block">
                        <h1>Most Popular Tour Packages</h1>
                        <p>Here is the top tour packages available around Kerala, The God's own Country</p>
                    </div>
                    <div class="tour-packages row add-clearfix image-box">
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInLeft">
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/munnarpackage.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3257</span>
                                        <h2 class="caption-title">Munnar Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInDown">
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/tp3.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3122</span>
                                        <h2 class="caption-title">Kumarakom City Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInRight">
                                <span class="discount"><span class="discount-text">10% Discount</span></span>
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/tp8.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3483</span>
                                        <h2 class="caption-title">Thekkady Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInLeft">
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/tp7.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3352</span>
                                        <h2 class="caption-title">Alleppy Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInUp">
                                <span class="discount"><span class="discount-text">10% Discount</span></span>
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/tp5.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3478</span>
                                        <h2 class="caption-title">Honeymoon Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <article class="box animated" data-animation-type="fadeInRight">
                                <figure>
                                    <a href="tour-detail"><img src="images/uploads/tp6.jpg" alt=""></a>
                                    <figcaption>
                                        <span class="price">INR 3175</span>
                                        <h2 class="caption-title">Kovalam Package</h2>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                </div>
            </div>

            <div class="global-map-area section parallax" data-stellar-background-ratio="0.5">
                <div class="container">
                    <div class="description text-center">
                        <h1>Our Customers Favourite Hotels</h1>
                        <!-- <p>Nunc cursus libero purusac congue arcu cursus utsed vitae pulvinar massa idporta neque.</p>
                        <p>Etiam elerisque mi id faucibus iaculis vitae pulvinar.</p> -->
                    </div>
                   <h2>Recommended Hotels</h2>
                    <div class="block image-carousel style2 flexslider" data-animation="slide" data-item-width="270" data-item-margin="30">
                        <ul class="slides image-box listing-style2">
                            <li>
                                <article class="box">
                                    <figure>
                                        <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/h1.png" alt="" width="270" height="160" /></a>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="hotel-detailed.html" class="pull-right button uppercase">select</a>
                                        <h4 class="box-title">Aveda</h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit">INR 3322</span>avg/night
                                        </label>
                                    </div>
                                </article>
                            </li>
                            <li>
                                <article class="box">
                                    <figure>
                                        <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/h2.png" alt="" width="270" height="160" /></a>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="hotel-detailed.html" class="pull-right button uppercase">select</a>
                                        <h4 class="box-title">Ramada</h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit">INR 3620</span>avg/night
                                        </label>
                                    </div>
                                </article>
                            </li>
                            <li>
                                <article class="box">
                                    <figure>
                                        <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/h3.png" alt="" width="270" height="160" /></a>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="hotel-detailed.html" class="pull-right button uppercase">select</a>
                                        <h4 class="box-title">Rain Forest</h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit">INR 3170</span>avg/night
                                        </label>
                                    </div>
                                </article>
                            </li>
                            <li>
                                <article class="box">
                                    <figure>
                                        <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/h4.png" alt="" width="270" height="160" /></a>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="hotel-detailed.html" class="pull-right button uppercase">select</a>
                                        <h4 class="box-title">Marriot</h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit">INR 3120</span>avg/night
                                        </label>
                                    </div>
                                </article>
                            </li>
                            <li>
                                <article class="box">
                                    <figure>
                                        <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img src="images/uploads/h6.png" alt="" width="270" height="160" /></a>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="hotel-detailed.html" class="pull-right button uppercase">select</a>
                                        <h4 class="box-title">Chandy's Windy Woods</h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit">INR 3322</span>avg/night
                                        </label>
                                    </div>
                                </article>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="container section">
                <h2>Explore Our Best Destinations</h2>
                <div class="row image-box style10">
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt1.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Alleppy<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt2.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Athirapilly<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt3.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Cochin<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt4.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Kumarakom<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt5.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Munnar<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt6.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Thekkady<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt1.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Alleppy<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                    <div class="col-sms-6 col-sm-6 col-md-3">
                        <article class="box">
                            <figure class="animated" data-animation-type="fadeInDown" data-animation-duration="2">
                                <a href="hotel-list-view.html" title="" class="hover-effect"><img src="images/uploads/tt2.png" alt="" width="270" height="160" /></a>
                            </figure>
                            <div class="details">
                                <a href="hotel-list-view.html" class="button btn-mini">SEE ALL</a>
                                <h4 class="box-title">Athirapilly<small>(990 places)</small></h4>
                            </div>
                        </article>
                    </div>
                </div>
            </div>

            <div class="global-map-area section parallax" data-stellar-background-ratio="0.5">
                <div class="container description">
                    <div class="col-sm-6 col-md-4">
                        <div class="icon-box style6 animated" data-animation-type="slideInLeft" data-animation-delay="0">
                            <i class="soap-icon-friends"></i>
                            <div class="description">
                                <h4 class="box-title">Tour Packages</h4>
                                <p>Dedicated custom-made different types of Holiday tour packages</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="icon-box style6 animated" data-animation-type="slideInDown" data-animation-delay="0.6">
                            <i class="soap-icon-pickanddrop"></i>
                            <div class="description">
                                <h4 class="box-title">Online Booking</h4>
                                <p>Online Bookings of Air tickets/ Hotels /Homestays / Restaurants, Cars, Bus, Force Traveler, Vans etc</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="icon-box style6 animated" data-animation-type="slideInDown" data-animation-delay="0.9">
                            <i class="soap-icon-insurance"></i>
                            <div class="description">
                                <h4 class="box-title">MICE</h4>
                                <p>MICE (Meetings, incentives, conferences and exhibitions or Events)</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        
       <?php include_once('footer.php');?>
    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- load revolution slider scripts -->
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.revolution.min.js"></script>

    <!-- Flex Slider -->
    <script type="text/javascript" src="components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- load BXSlider scripts -->
    <script type="text/javascript" src="components/jquery.bxslider/jquery.bxslider.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
    <script type="text/javascript">
        tjq(document).ready(function() {
            tjq('.revolution-slider').revolution(
            {
                sliderType:"standard",
				sliderLayout:"auto",
				dottedOverlay:"none",
				delay:9000,
				navigation: {
					keyboardNavigation:"off",
					keyboard_direction: "horizontal",
					mouseScrollNavigation:"off",
					mouseScrollReverse:"default",
					onHoverStop:"on",
					touch:{
						touchenabled:"on",
						swipe_threshold: 75,
						swipe_min_touches: 1,
						swipe_direction: "horizontal",
						drag_block_vertical: false
					}
					,
					arrows: {
						style:"default",
						enable:true,
						hide_onmobile:false,
						hide_onleave:false,
						tmp:'',
						left: {
							h_align:"left",
							v_align:"center",
							h_offset:20,
							v_offset:0
						},
						right: {
							h_align:"right",
							v_align:"center",
							h_offset:20,
							v_offset:0
						}
					}
				},
				visibilityLevels:[1240,1024,778,480],
				gridwidth:1170,
				gridheight:646,
				lazyType:"none",
				shadow:0,
				spinner:"spinner4",
				stopLoop:"off",
				stopAfterLoops:-1,
				stopAtSlide:-1,
				shuffle:"off",
				autoHeight:"off",
				hideThumbsOnMobile:"off",
				hideSliderAtLimit:0,
				hideCaptionAtLimit:0,
				hideAllCaptionAtLilmit:0,
				debugMode:false,
				fallbacks: {
					simplifyAll:"off",
					nextSlideOnWindowFocus:"off",
					disableFocusListener:false,
				}
            });
        });
    </script>
</body>
</html>