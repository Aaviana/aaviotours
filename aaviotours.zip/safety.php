<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
        <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">Safety Tips</h2>
                </div>
                
            </div>
        </div>

        <section id="content">
            <div class="container">
                <div id="main">
                    <div class="tab-container style1 travelo-policies">
                        <ul class="tabs full-width">
                            <li class="active"><a data-toggle="tab" href="#terms-services">About Kerala</a></li>
                            <li><a data-toggle="tab" href="#privacy-policy">How to travel Kerala</a></li>
                            <li><a data-toggle="tab" href="#guest-refund-policy">Things to remember</a></li>
                            <li><a data-toggle="tab" href="#copyright-policy">Helpline Numbers </a></li>
                           
                        </ul>
                        <div class="tab-content">
                            <div id="terms-services" class="tab-pane fade in active">
                               
                                <div class="policy">
                                    <h2>About Kerala</h2>
                                    <p>Kerala is blessed with abundant rainfall, innumerable rivers, beaches, backwaters, Hilly Mountains and Wild Life. With the Arabian Sea in the west, the Western Ghats towering 500-2700 m in the east and networked by 44 rivers, Kerala enjoys unique geographical features that have made it one of the most sought after tourist destinations in Asia. An equable climate. A long shoreline with serene beaches. Tranquil stretches of emerald backwaters. Lush hill stations and exotic wildlife. Waterfalls. Sprawling plantations and paddy fields. Ayurvedic health holidays. Enchanting art forms. Magical festivals. Historic and cultural monuments. An exotic cuisine... All of which offer you a unique experience. And what's more, each of these charming destinations is only a two hour drive from the other - a singular advantage no other destination offers </p>
                                </div>
                                <hr>
                                
                               

                            </div>
                            <div id="privacy-policy" class="tab-pane fade">
                                
								 <div class="policy">
                                    <h2>How to travel Kerala </h2>
                                    <p>
										<b>AIR: </b> Kerala is well connected with rest of the world having three International Airports, Cochin International Airport, Trivandrum International Airport and Calicut International Airport. Perunad Helipad and Willingdon Island Air Base also there.<br>
										<b>TRAINS: </b> Booking to main Junctions like Ernakulam Junction, Calicut, Thrissur, Palakkad, Kannur, Kasarkode, Kottayam, Alleppy, Kollam Junction, Kochuveli Junction or Trivandrum Central.<br><br>

										<b>Surface Transportation: </b> State Government Transport busses and private bus operators are present to commute passengers across state and interstate also. Private cars, cabs, mini busses, traveler, auto rickshaw etc available in numbers. App based car booking services are also in the state. <br><br>

										We suggest that you should Never forget to make a detailed plan of where to go, where to stay and what to do before you start the trip. 

									</p>
                                </div>
                                <hr>
								
                            </div>
                            <div id="guest-refund-policy" class="tab-pane fade">
                                
								 <div class="policy">
                                    <h2>Things to remember </h2>
                                    <p>
									Every place you visit in Kerala Will have different Weather. Some areas have dry hot weather, some humid and some are so cool that you need warm clothes. Rains need no invitation in Kerala, so be prepared for rains any calendar month, keeping umbrella is a worthy advise. It would be wise to study climate changes on ‘whether portals’ before you start.<br><br>

Foreign Passengers should apply for the VISA at least 14 Days before date of arrival and should get travel insurance.
For trips to Munnar or such Hilly areas, so carry warm or woolen clothes. Special care for infants and children.
Some places are sweaty and warm like Kochi so carry some Cotton apparel and umbrella if it is sunny to protect from burning sun.
Take sunscreen, sun glasses etc. and drinking water or juice or some energy drinks and also wear comfortable footwear. Carry a small First Aid box.
Please do not forget your Passport, Identity Cards, Travel Insurance numbers etc.
Carrying too much cash is not advisable, because most of the selling spots have digital payments facility.
Plan well in advance for your stay, i.e. Hotels/Motels/ Houseboats /Resorts/ Homestay.
Smoking and Drinking alcohol at public places is prohibited 
Hugging, Kissing, Nudity is not allowed at any place. Women should be careful not getting too friendly with unknown males, Kerala also has migrants as well as criminals, so better to take precautionary step.
Take the packed meals or breakfast only.
Take care of your bags etc. and mobile, tab, camera etc.

									
									</p>
                                </div>
                                <hr>
								
                            </div>
                            <div id="copyright-policy" class="tab-pane fade">
                                
								 <div class="policy">
                                    <h2>Helpline Numbers </h2>
                                    <ul>
								<li>Medical Helpline Number-102, 108, 112</li>
								<li>Police Helpline Number– 100</li>
								<li>Kerala Police Helpline No- 0471-3243000 ,0471-3244000 ,0471-3245000</li>
								<li>Highway Help Number-9846 100 100</li>
								<li>Women Helpline: 1091</li>
								<li>Child helpline: 1098</li>
								</ul>
								<p>For more, please click:<a href="https://kerala.gov.in/helpline"> Help Lines</a></p>
								<br>
								<p>Aaviotours Helpline Numbers : 86065 01234 | 86064 01234 | 80977 95909 | Whatsapp 88798 60520</p>
                                </div>
                                <hr>
								
                            </div>
                            <div id="acceptable-usage-policy" class="tab-pane fade">
                                
                            </div>
                            <div id="terms-business" class="tab-pane fade">
                                
                            </div>
                            <div id="cancellations" class="tab-pane fade">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php include_once('footer.php');?>
    </div>


    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
</body>
</html>

