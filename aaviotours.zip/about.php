<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
        <?php include_once('header.php');?>

        <div class="page-title-container">
            <div class="container">
                <div class="page-title pull-left">
                    <h2 class="entry-title">About Us</h2>
                </div>
                
            </div>
        </div>

        <section id="content">
            <div class="container">
                <div id="main">
                    <div class="large-block image-box style6">
                        <article class="box">
                            <figure class="col-md-5">
                                <a href="#" title="" class="middle-block"><img class="middle-item" src="images/uploads/about2.jpeg" alt="" width="476" height="318" /></a>
                            </figure>
                            <div class="details col-md-offset-5">
                                <h4 class="box-title">Who We Are?</h4>
                                <p> aaviotours.in is a part of Aaviana Tourism LLP,&nbsp; a sister concern of Aaviana Trading LLP engaged in online sales,&nbsp; bulk sales and Exports of Kerala based Products & Services and Aaviana Real Estate LLP.&nbsp; All our companies are  registered with Ministry of Corporate Affairs under LLP act 2008.</p>
                            </div>
                        </article>
                        <article class="box">
                            <figure class="col-md-5 pull-right middle-block">
                                <a href="#" title=""><img class="middle-item" src="images/uploads/about4.jpeg" alt="" width="476" height="318" /></a>
                            </figure>
                            <div class="details col-md-7">
                                <h4 class="box-title">What We Do?</h4>
                                <p>We are starting this Tourism venture with an objective to promote tourism in Kerala and providing tour packages of rest of India and abroad to Keralites.&nbsp; We are dedicated for our top class services and for the unparalleled services we offer to those who come to explore the ‘God’s Own Country’.&nbsp; Kerala is blessed with abundant rainfall and innumerable rivers.&nbsp; It offers beaches ,&nbsp;backwater,&nbsp; cool mountain ,&nbsp; wild life and top of all its rich culture and heritage .</p>
                            </div>
                        </article>
                        <article class="box">
                            <figure class="col-md-5">
                                <a href="#" title="" class="middle-block"><img class="middle-item" src="images/uploads/about3.jpeg" alt="" /></a>
                            </figure>
                            <div class="details col-md-offset-5">
                                <h4 class="box-title">How Aaviotours Works?</h4>
                                <p>Aaviana Group wants to bring all such services on one platform.&nbsp; Whether it is a car driver or a cab service company,&nbsp; a hotel or a group of hotels,&nbsp; a houseboat or a small village house for homestay,&nbsp; all are on one platform called aaviotours.in</p>
                            </div>
                        </article>
						 <article class="box">
                            <figure class="col-md-5 pull-right middle-block">
                                <a href="#" title=""><img class="middle-item" src="images/uploads/about1.jpeg" alt="" width="476" height="318" /></a>
                            </figure>
                            <div class="details col-md-7">
                                <h4 class="box-title">Our Core Services?</h4>
								<ul>
								<li>Dedicated custom-made different types of Holiday tour packages.</li>
								<li>Online Bookings of Air tickets/ Hotels /Homestays / Restaurants,&nbsp; Cars,&nbsp; Bus,&nbsp; Force Traveler,&nbsp; Vans etc.</li>
								<li>Online Booking of Boats & Houseboats.</li>
								<li>MICE (Meetings,&nbsp; Incentives,&nbsp; Conferences and Exhibitions or Events)</li>
								</ul>
                            </div>
                        </article>
                    </div>

                    

                    <div class="large-block">
                        <h2>Aavio Tours Dedicated Team</h2>
                        <div class="row image-box style1 team">
                            <div class="col-sm-6 col-md-3">
                                <article class="box">
                                   
                                    <div class="details">
                                        <h4 class="box-title"><a href="#">Mr. Starwin Issac<small>The Director</small></a></h4>
                                        <p class="description">MBA in Retail Operations,&nbsp; having more than 20 years of working experience in various corporate on various positions. Decided to come back to Kerala from Mumbai in 2016 to with an intention to serve his own motherland,&nbsp; State called Kerala the God’s Own Country. </p>
                                       
                                    </div>
                                </article>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <article class="box">
                                    
                                    <div class="details">
                                        <h4 class="box-title"><a href="#">Ms. Varsha Shivdasan <small>Head - Operations </small></a></h4>
                                        <p class="description">A graduate in Tourism having experience in the similar positions, able to chart out plans and strategies for a better and unique ideas and ways to make holidays a lifelong experiences. Her well planned business statergies can give a profitable revenue to our business associaties.<br></p>
                                       
                                    </div>
                                </article>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <article class="box">
                                   
                                    <div class="details">
                                        <h4 class="box-title"><a href="#">Mr. Hari Krishnan Nair <small>Head - Sales & Marketing </small></a></h4>
                                        <p class="description">MBA in Sales & Marketing. Helps in promoting Tourism among tourists and finding new clients to take our services to the next level. He will be happy to assist you.<br><br><br> </p>
                                       
                                    </div>
                                </article>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <article class="box">
                                    
                                    <div class="details">
                                        <h4 class="box-title"><a href="#">Mr. Muhssin K Salim<small>Technical Head </small></a></h4>
                                        <p class="description">B. Tech degree with years of proven track record with various tours & travels companies. His web development skills make our group companies grow, we fully rely on his skills<br><br><br></p>
                                        
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>

                   
                </div>
            </div>
        </section>
        
        <?php include_once('footer.php');?>
    </div>


    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
</body>
</html>

