<!DOCTYPE html>
<!--[if IE 8]>          <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>          <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->  <html> <!--<![endif]-->
<head>
    <!-- Page Title -->
    <title>Aavio Tours Your kerala tourism partner</title>
    
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="keywords" content="Aavio Tours,kerala tourism,Tour to kerala" />
    <meta name="description" content="Aavio Tours Your kerala tourism partner">
    <meta name="author" content="Aavio tours">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
    
    <!-- Current Page Styles -->
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/settings.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/revolution_slider/css/style.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/jquery.bxslider/jquery.bxslider.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="components/flexslider/flexslider.css" media="screen" />
    
    <!-- Main Style -->
    <link id="main-style" rel="stylesheet" href="css/style.css">
    
    <!-- Updated Styles -->
    <link rel="stylesheet" href="css/updates.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="css/custom.css">
    
    <!-- Responsive Styles -->
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- CSS for IE -->
    <!--[if lte IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
    <![endif]-->
    

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script type='text/javascript' src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
</head>
<body>
    <div id="page-wrapper">
         <?php include_once('header.php');?>
        <section id="content" class="image-bg1">
            <div class="container">
                <div class="row">
                    <div id="main" style="left:0;right:0;position:absolute;" class="col-sm-8 col-md-9">
                        <div class="search-box-wrapper style1">
                            <div class="search-box">
                                <ul class="search-tabs clearfix"> 
                                    <li class="active in"><a href="#hotels-tab" data-toggle="tab"><i class="soap-icon-hotel"></i>HOTELS</a></li>
                                    <li><a href="#cars-tab" data-toggle="tab"><i class="soap-icon-car"></i>CARS</a></li>
                                    <li><a href="#cruises-tab" data-toggle="tab"><i class="soap-icon-cruise"></i>HOUSE BOATS</a></li>
                                    <li><a href="#flight-status-tab" data-toggle="tab"><i class="soap-icon-status"></i>TOUR PACKAGES</a></li>
                                </ul>
                                <div class="visible-mobile">
                                    <ul id="mobile-search-tabs" class="search-tabs clearfix">
                                        <li class="active"><a href="#hotels-tab">HOTELS</a></li>
                                        <li><a href="#cars-tab">CARS</a></li>
                                        <li><a href="#cruises-tab">HOUSE BOATS</a></li>
                                        <li><a href="#flight-status-tab">TOUR PACKAGES</a></li>
										
                                    </ul>
                                </div>
                                
                                <div class="search-tab-content" style="">
                                    <div class="tab-pane fade active in" id="hotels-tab">
                                       <form name="sellerform" method="post" action="http://aavio.in/sellerAction1.php">
			<table class="table table-bordered table-hover" id="tab_logic">
				<tbody>
				<div class="title-container">
                                                <h2 class="search-title">Hotels Registration Form</h2>
                                                <p>We're bringing you a new level of business.</p>
                                                <i class="soap-icon-hotel"></i>
                                            </div>
					<tr id='addr0'>
						<td>
						Name of Business
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='nameofestablish'   class="form-control" required/>
						</td>
						<td>
						PAN No.
						</td>
						<td>
						<input type="text" name='panno'   class="form-control"/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>Address of Business <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='address'  placeholder='Line 1' class="form-control" required/></td>
						<td colspan="2"><input type="text" name='address'  placeholder='Line 2' class="form-control"/></td>
					</tr>
					
					<tr id='addr0'>
						<td>District <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='district'   class="form-control" required/></td>
						<td>PIN <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='pin'  placeholder='' class="form-control" maxlength="6" pattern="[0-9]{6,6}" oninvalid="setCustomValidity('Pin no should be 6 digits')" onchange="try{setCustomValidity('')}catch(e){}" required/></td>
					</tr>
					<tr id='addr0'>
						<td>
						Owner/Proprietor's Name <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='ownername'  placeholder='' class="form-control" required/>
						</td>
						<td>
						Official Email ID <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="email" name='tinno'  placeholder='' class="form-control" required/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>
						Partner's if any</td>
						<td>
						<input type="text" name='partnername1'  placeholder='Partner Name 1' class="form-control"/>
						</td>
						<td>
						Mob No.
						</td>
						<td>
						<input type="text" name='partnermobno1'  placeholder='' class="form-control" maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}"/>
						</td>
					</tr>
					
					<input type="hidden" name="sellertype" id="sellertype" value="hotels">
					<tr id='addr0'>
						<td>
						Name of Authorised person
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='authorised'  placeholder='' class="form-control" required/>
						</td>
						<td>
						
						<input type="text" name='auth_mobno'  placeholder='Mob No.' class="form-control" maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" required/>
						</td>
						<td>
						
						<input type="email" name='auth_email'  placeholder='Email ID' class="form-control" required/>
						</td>
					</tr>
					
					
					
					
					<tr id='addr0'>
						<td>Bank Details: Account Holder <font color="#FF0000">
						<b>*</b></font></td>
						<td><input type="text" name='acc_holder'  placeholder='' class="form-control" required/></td>
						
					</tr>
					
					<tr id='addr0'>
						<td>Account No. <font color="#FF0000"><b>*</b></font></td>
						<td><input type="number" name='acc_no'  placeholder='' class="form-control" required/></td>
						<td>Bank <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_bank'  placeholder='' class="form-control" required/></td>
					</tr>
					
					<tr id='addr0'>
						<td>Branch <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_branch'  placeholder='' class="form-control" required/></td>
						<td>IFSC Code <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_ifsc'  placeholder='' class="form-control" required/></td>
					</tr>
					
					
					
					<tr id='addr0'>
						<td>Your details, to put on our site</td>
						<td colspan="3"><textarea name="others" class="form-control"></textarea></td>
						
					</tr>
					
					
				
                     
					<tr id='addr0'>
						<td colspan="4"><button type="submit" class="full-width btn-medium">Submit</button></td>
						
					</tr>
				</tbody>
			</table>
			</form>
                                    </div>
                                   
                                   
                                    <div class="tab-pane fade" id="cars-tab">
                                        <form name="sellerform" method="post" action="http://aavio.in/sellerAction1.php" onkeypress="return event.keyCode != 13;">
			<table class="table table-bordered table-hover" id="tab_logic">
				<tbody>
				<div class="title-container">
                                                <h2 class="search-title">Cars Registration Form</h2>
                                                <p>We're bringing you a new level of business.</p>
                                                <i class="soap-icon-hotel"></i>
                                            </div>
					<tr id='addr0'>
						<td>
						Name of Business
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='nameofestablish'   class="form-control" required/>
						</td>
						<td>
						PAN/ST No.
						</td>
						<td>
						<input type="text" name='panno'   class="form-control"/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>Address of Business <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='address'  placeholder='Line 1' class="form-control" required/></td>
						<td colspan="2"><input type="text" name='address'  placeholder='Line 2' class="form-control"/></td>
					</tr>
					
					<tr id='addr0'>
						<td>District <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='district'   class="form-control" required/></td>
						<td>PIN <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='pin'  placeholder='' class="form-control" maxlength="6" pattern="[0-9]{6,6}" oninvalid="setCustomValidity('Pin no should be 6 digits')" onchange="try{setCustomValidity('')}catch(e){}" required/></td>
					</tr>
					<tr id='addr0'>
						<td>
						Owner/Proprietor's Name <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='ownername'  placeholder='' class="form-control" required/>
						</td>
						<td>
						Official Email ID <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="email" name='tinno'  placeholder='' class="form-control" required/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>
						Partner's if any</td>
						<td>
						<input type="text" name='partnername1'  placeholder='Partner Name 1' class="form-control"/>
						</td>
						<td>
						Mob No.
						</td>
						<td>
						<input type="text" name='partnermobno1'  placeholder='' maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control"/>
						</td>
					</tr>
					
					<input type="hidden" name="sellertype" id="sellertype" value="cars">
					<tr id='addr0'>
						<td>
						Name of Authorised person
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='authorised'  placeholder='' class="form-control" required/>
						</td>
						<td>
						
						<input type="text" name='auth_mobno'  placeholder='Mob No.' maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control" required/>
						</td>
						<td>
						
						<input type="email" name='auth_email'  placeholder='Email ID' class="form-control" required/>
						</td>
					</tr>
					
					
					
					
					<tr id='addr0'>
						<td>Bank Details: Account Holder <font color="#FF0000">
						<b>*</b></font></td>
						<td><input type="text" name='acc_holder'  placeholder='' class="form-control" required/></td>
						
					</tr>
					
					<tr id='addr0'>
						<td>Account No. <font color="#FF0000"><b>*</b></font></td>
						<td><input type="number" name='acc_no'  placeholder='' class="form-control" required/></td>
						<td>Bank <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_bank'  placeholder='' class="form-control" required/></td>
					</tr>
					
					<tr id='addr0'>
						<td>Branch <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_branch'  placeholder='' class="form-control" required/></td>
						<td>IFSC Code <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_ifsc'  placeholder='' class="form-control" required/></td>
					</tr>
					
					
					
					<tr id='addr0'>
						<td>Your details, to put on our site</td>
						<td colspan="3"><textarea name="others" class="form-control"></textarea></td>
						
					</tr>
					
					
				
                     
					<tr id='addr0'>
						<td colspan="4"><button type="submit" class="full-width btn-medium">Submit</button></td>
						
					</tr>
				</tbody>
			</table>
			</form>
                                    </div>
                                    <div class="tab-pane fade" id="cruises-tab">
                                        <form name="sellerform" method="post" action="http://aavio.in/sellerAction1.php" onkeypress="return event.keyCode != 13;">
			<table class="table table-bordered table-hover" id="tab_logic">
				<tbody>
				<div class="title-container">
                                                <h2 class="search-title">Houseboat Registration Form</h2>
                                                <p>We're bringing you a new level of business.</p>
                                                <i class="soap-icon-hotel"></i>
                                            </div>
					<tr id='addr0'>
						<td>
						Name of Business
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='nameofestablish'   class="form-control" required/>
						</td>
						<td>
						PAN No.
						</td>
						<td>
						<input type="text" name='panno'   class="form-control"/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>Address of Business <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='address'  placeholder='Line 1' class="form-control" required/></td>
						<td colspan="2"><input type="text" name='address'  placeholder='Line 2' class="form-control"/></td>
					</tr>
					
					<tr id='addr0'>
						<td>District <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='district'   class="form-control" required/></td>
						<td>PIN <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='pin'  placeholder='' class="form-control" maxlength="6" pattern="[0-9]{6,6}" oninvalid="setCustomValidity('Pin no should be 6 digits')" onchange="try{setCustomValidity('')}catch(e){}" required/></td>
					</tr>
					<tr id='addr0'>
						<td>
						Owner/Proprietor's Name <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='ownername'  placeholder='' class="form-control" required/>
						</td>
						<td>
						Official Email ID <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="email" name='tinno'  placeholder='' class="form-control" required/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>
						Partner's if any</td>
						<td>
						<input type="text" name='partnername1'  placeholder='Partner Name 1' class="form-control"/>
						</td>
						<td>
						Mob No.
						</td>
						<td>
						<input type="text" name='partnermobno1'  placeholder='' maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control"/>
						</td>
					</tr>
					
					<input type="hidden" name="sellertype" id="sellertype" value="houseboats">
					<tr id='addr0'>
						<td>
						Name of Authorised person
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='authorised'  placeholder='' class="form-control" required/>
						</td>
						<td>
						
						<input type="text" name='auth_mobno'  placeholder='Mob No.' maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control" required/>
						</td>
						<td>
						
						<input type="email" name='auth_email'  placeholder='Email ID' class="form-control" required/>
						</td>
					</tr>
					
					
					
					
					<tr id='addr0'>
						<td>Bank Details: Account Holder <font color="#FF0000">
						<b>*</b></font></td>
						<td><input type="text" name='acc_holder'  placeholder='' class="form-control" required/></td>
						
					</tr>
					
					<tr id='addr0'>
						<td>Account No. <font color="#FF0000"><b>*</b></font></td>
						<td><input type="number" name='acc_no'  placeholder='' class="form-control" required/></td>
						<td>Bank <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_bank'  placeholder='' class="form-control" required/></td>
					</tr>
					
					<tr id='addr0'>
						<td>Branch <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_branch'  placeholder='' class="form-control" required/></td>
						<td>IFSC Code <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_ifsc'  placeholder='' class="form-control" required/></td>
					</tr>
					
					
					
					<tr id='addr0'>
						<td>Your details, to put on our site</td>
						<td colspan="3"><textarea name="others" class="form-control"></textarea></td>
						
					</tr>
					
					
                     
					<tr id='addr0'>
						<td colspan="4"><button type="submit" class="full-width btn-medium">Submit</button></td>
						
					</tr>
				</tbody>
			</table>
			</form>
                                    </div>
                                    <div class="tab-pane fade" id="flight-status-tab">
                                        <form name="sellerform" method="post" action="http://aavio.in/sellerAction1.php" onkeypress="return event.keyCode != 13;">
			<table class="table table-bordered table-hover" id="tab_logic">
				<tbody>
				<div class="title-container">
                                                <h2 class="search-title">Tours & Travel Agencies Registration Form</h2>
                                                <p>We're bringing you a new level of business.</p>
                                                <i class="soap-icon-hotel"></i>
                                            </div>
					<tr id='addr0'>
						<td>
						Name of Business
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='nameofestablish'   class="form-control" required/>
						</td>
						<td>
						PAN No.
						</td>
						<td>
						<input type="text" name='panno'   class="form-control"/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>Address of Business <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='address'  placeholder='Line 1' class="form-control" required/></td>
						<td colspan="2"><input type="text" name='address'  placeholder='Line 2' class="form-control"/></td>
					</tr>
					
					<tr id='addr0'>
						<td>District <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='district'   class="form-control" required/></td>
						<td>PIN <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='pin'  placeholder='' min="100000"  max = "999999" pattern="[0-9]{6,6}" oninvalid="setCustomValidity('Pin no should be 6 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control" required/></td>
					</tr>
					<tr id='addr0'>
						<td>
						Owner/Proprietor's Name <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='ownername'  placeholder='' class="form-control" required/>
						</td>
						<td>
						Official Email ID <font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="email" name='tinno'  placeholder='' class="form-control" required/>
						</td>
					</tr>
					<tr id='addr0'>
						<td>
						Partner's if any</td>
						<td>
						<input type="text" name='partnername1'  placeholder='Partner Name 1' class="form-control"/>
						</td>
						<td>
						Mob No.
						</td>
						<td>
						<input type="text" name='partnermobno1'  placeholder='' maxlength="10" pattern="[0-9]{10,10}" oninvalid="setCustomValidity('Mobile no should be 10 digits')" onchange="try{setCustomValidity('')}catch(e){}" class="form-control"/>
						</td>
					</tr>
					
					<input type="hidden" name="sellertype" id="sellertype" value="tours">
					<tr id='addr0'>
						<td>
						Name of Authorised person
						<font color="#FF0000"><b>*</b></font></td>
						<td>
						<input type="text" name='authorised'  placeholder='' class="form-control" required/>
						</td>
						<td>
						
						<input type="number" name='auth_mobno'  placeholder='Mob No.' class="form-control" required/>
						</td>
						<td>
						
						<input type="email" name='auth_email'  placeholder='Email ID' class="form-control" required/>
						</td>
					</tr>
					
					
					
					
					<tr id='addr0'>
						<td>Bank Details: Account Holder <font color="#FF0000">
						<b>*</b></font></td>
						<td><input type="text" name='acc_holder'  placeholder='' class="form-control" required/></td>
						
					</tr>
					
					<tr id='addr0'>
						<td>Account No. <font color="#FF0000"><b>*</b></font></td>
						<td><input type="number" name='acc_no'  placeholder='' class="form-control" required/></td>
						<td>Bank <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_bank'  placeholder='' class="form-control" required/></td>
					</tr>
					
					<tr id='addr0'>
						<td>Branch <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_branch'  placeholder='' class="form-control" required/></td>
						<td>IFSC Code <font color="#FF0000"><b>*</b></font></td>
						<td><input type="text" name='acc_ifsc'  placeholder='' class="form-control" required/></td>
					</tr>
					
					
					
					<tr id='addr0'>
						<td>Your details, to put on our site</td>
						<td colspan="3"><textarea name="others" class="form-control"></textarea></td>
						
					</tr>
					
                     
					<tr id='addr0'>
						<td colspan="4"><button type="submit" class="full-width btn-medium">Submit</button></td>
						
					</tr>
				</tbody>
			</table>
			</form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        
		
         <?php include_once('footer.php');?>
    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="js/bootstrap.js"></script>
    
    <!-- load revolution slider scripts -->
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="components/revolution_slider/js/jquery.themepunch.revolution.min.js"></script>

    <!-- Flex Slider -->
    <script type="text/javascript" src="components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- load BXSlider scripts -->
    <script type="text/javascript" src="components/jquery.bxslider/jquery.bxslider.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="js/theme-scripts.js"></script>
    <script type="text/javascript" src="js/scripts.js"></script>
    
    <script type="text/javascript">
        
    </script>
	
	
	<!-- added script-->

	<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.js"></script>
	
	
	
	
	
</body>
</html>

